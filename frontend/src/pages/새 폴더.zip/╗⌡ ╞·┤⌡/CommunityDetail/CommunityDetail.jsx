import { useEffect, useState } from "react";
import "./CommunityDetail.css";

const API_BASE_URL =
  import.meta.env.VITE_API_URL || "http://localhost:8080";

function CommunityDetail({
  post,
  currentUser,
  isLoggedIn,
  getImageUrl,
  onClose,
  onUpdated,
  onDeleted,
}) {
  const [isLiked, setIsLiked] = useState(
    Boolean(
      post?.likedByCurrentUser ??
        post?.liked ??
        post?.isLiked ??
        false
    )
  );

  const [likeCount, setLikeCount] = useState(
    Number(post?.likeCount || 0)
  );

  const [liking, setLiking] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const [showEdit, setShowEdit] = useState(false);
  const [saving, setSaving] = useState(false);

  const [editTitle, setEditTitle] = useState(
    post?.title || ""
  );

  const [editContent, setEditContent] = useState(
    post?.content || ""
  );


  /* =====================================================
     작성자
  ===================================================== */

  const author =
    post?.author ||
    post?.nickname ||
    "알 수 없음";

  const category =
    post?.category ||
    post?.categoryName ||
    "정보공유";


  /* =====================================================
     현재 사용자가 작성자인지 확인
  ===================================================== */

  const isAuthor = () => {
    if (!post || !currentUser || !isLoggedIn) {
      return false;
    }

    /*
     * 백엔드에서 직접 작성자 여부를 내려주는 경우
     */
    if (typeof post.isAuthor === "boolean") {
      return post.isAuthor;
    }

    /*
     * 게시글 작성자 ID
     */
    const authorId =
      post.authorId ??
      post.memberId ??
      post.userId;

    /*
     * 현재 로그인 사용자 ID
     */
    const currentUserId =
      currentUser.id ??
      currentUser.memberId ??
      currentUser.userId;

    /*
     * ID가 둘 다 존재하면 ID 비교
     */
    if (
      authorId !== undefined &&
      authorId !== null &&
      currentUserId !== undefined &&
      currentUserId !== null
    ) {
      return (
        String(authorId) ===
        String(currentUserId)
      );
    }

    /*
     * ID가 없는 경우 이메일 비교
     */
    const authorEmail =
      post.authorEmail ??
      post.email;

    const currentUserEmail =
      currentUser.email;

    if (
      authorEmail &&
      currentUserEmail
    ) {
      return (
        authorEmail ===
        currentUserEmail
      );
    }

    /*
     * 마지막으로 닉네임 비교
     */
    const authorNickname =
      post.author ??
      post.nickname;

    const currentNickname =
      currentUser.nickname;

    if (
      authorNickname &&
      currentNickname
    ) {
      return (
        authorNickname ===
        currentNickname
      );
    }

    return false;
  };


  /* =====================================================
     날짜
  ===================================================== */

  const formatDateTime = (date) => {
    if (!date) {
      return "";
    }

    const parsedDate = new Date(date);

    if (Number.isNaN(parsedDate.getTime())) {
      return "";
    }

    return parsedDate.toLocaleString(
      "ko-KR"
    );
  };


  /* =====================================================
     좋아요
  ===================================================== */

  const handleLike = async () => {
    if (!isLoggedIn) {
      alert(
        "좋아요는 로그인 후 이용할 수 있습니다."
      );
      return;
    }

    if (liking || !post?.id) {
      return;
    }

    try {
      setLiking(true);

      const response = await fetch(
        `${API_BASE_URL}/community/posts/${post.id}/like`,
        {
          method: "POST",
          credentials: "include",
        }
      );

      if (!response.ok) {
        const message =
          await response.text();

        throw new Error(
          message ||
            "좋아요 처리에 실패했습니다."
        );
      }

      const data =
        await response.json();

      let nextLiked;
      let nextLikeCount;

      if (
        data &&
        typeof data === "object"
      ) {
        if (
          data.liked !== undefined
        ) {
          nextLiked =
            Boolean(data.liked);
        } else if (
          data.isLiked !== undefined
        ) {
          nextLiked =
            Boolean(data.isLiked);
        } else {
          nextLiked = !isLiked;
        }

        if (
          data.likeCount !== undefined
        ) {
          nextLikeCount =
            Number(data.likeCount);
        } else {
          nextLikeCount = nextLiked
            ? likeCount + 1
            : Math.max(
                0,
                likeCount - 1
              );
        }
      } else {
        nextLiked = !isLiked;

        nextLikeCount = nextLiked
          ? likeCount + 1
          : Math.max(
              0,
              likeCount - 1
            );
      }

      setIsLiked(nextLiked);
      setLikeCount(nextLikeCount);

      if (onUpdated) {
        await onUpdated({
          ...post,
          likeCount: nextLikeCount,
          liked: nextLiked,
          isLiked: nextLiked,
          likedByCurrentUser: nextLiked,
        });
      }
    } catch (error) {
      console.error(
        "좋아요 오류:",
        error
      );

      alert(
        error.message ||
          "좋아요 처리에 실패했습니다."
      );
    } finally {
      setLiking(false);
    }
  };


  /* =====================================================
     수정
  ===================================================== */

  const handleUpdate = async (event) => {
    event.preventDefault();

    if (!isLoggedIn) {
      alert(
        "로그인 후 이용할 수 있습니다."
      );
      return;
    }

    if (!isAuthor()) {
      alert(
        "작성자만 게시글을 수정할 수 있습니다."
      );
      return;
    }

    if (!editTitle.trim()) {
      alert("제목을 입력해주세요.");
      return;
    }

    if (!editContent.trim()) {
      alert("내용을 입력해주세요.");
      return;
    }

    if (saving) {
      return;
    }

    try {
      setSaving(true);

      const response = await fetch(
        `${API_BASE_URL}/community/posts/${post.id}`,
        {
          method: "PUT",
          credentials: "include",
          headers: {
            "Content-Type":
              "application/json",
          },
          body: JSON.stringify({
            title: editTitle.trim(),
            content: editContent.trim(),
          }),
        }
      );

      if (!response.ok) {
        const message =
          await response.text();

        throw new Error(
          message ||
            "게시글 수정에 실패했습니다."
        );
      }

      const updatedPost =
        await response.json().catch(
          () => null
        );

      const finalPost =
        updatedPost || {
          ...post,
          title: editTitle.trim(),
          content: editContent.trim(),
        };

      setShowEdit(false);

      setEditTitle(
        finalPost.title || ""
      );

      setEditContent(
        finalPost.content || ""
      );

      alert(
        "게시글이 수정되었습니다."
      );

      if (onUpdated) {
        await onUpdated(finalPost);
      }
    } catch (error) {
      console.error(
        "게시글 수정 오류:",
        error
      );

      alert(
        error.message ||
          "게시글 수정에 실패했습니다."
      );
    } finally {
      setSaving(false);
    }
  };


  /* =====================================================
     삭제
  ===================================================== */

  const handleDelete = async () => {
    if (!isLoggedIn) {
      alert(
        "로그인 후 이용할 수 있습니다."
      );
      return;
    }

    if (!isAuthor()) {
      alert(
        "작성자만 게시글을 삭제할 수 있습니다."
      );
      return;
    }

    if (deleting) {
      return;
    }

    const confirmed =
      window.confirm(
        "정말 이 게시글을 삭제하시겠습니까?\n삭제한 게시글은 복구할 수 없습니다."
      );

    if (!confirmed) {
      return;
    }

    try {
      setDeleting(true);

      const response = await fetch(
        `${API_BASE_URL}/community/posts/${post.id}`,
        {
          method: "DELETE",
          credentials: "include",
        }
      );

      if (!response.ok) {
        const message =
          await response.text();

        throw new Error(
          message ||
            "게시글 삭제에 실패했습니다."
        );
      }

      alert(
        "게시글이 삭제되었습니다."
      );

      if (onDeleted) {
        await onDeleted();
      }
    } catch (error) {
      console.error(
        "게시글 삭제 오류:",
        error
      );

      alert(
        error.message ||
          "게시글 삭제에 실패했습니다."
      );
    } finally {
      setDeleting(false);
    }
  };


  /* =====================================================
     화면 잠금
  ===================================================== */

  useEffect(() => {
    const previousOverflow =
      document.body.style.overflow;

    document.body.style.overflow =
      "hidden";

    return () => {
      document.body.style.overflow =
        previousOverflow;
    };
  }, []);


  /* =====================================================
     post 변경 시 상태 동기화
  ===================================================== */

  useEffect(() => {
    if (!post) {
      return;
    }

    setLikeCount(
      Number(post.likeCount || 0)
    );

    setIsLiked(
      Boolean(
        post.likedByCurrentUser ??
          post.liked ??
          post.isLiked ??
          false
      )
    );

    setEditTitle(
      post.title || ""
    );

    setEditContent(
      post.content || ""
    );

    setShowEdit(false);
  }, [post]);


  /* =====================================================
     화면
  ===================================================== */

  if (!post) {
    return null;
  }

  return (
    <main className="community-detail-page">

      {/* HEADER */}

      <header className="community-detail-header">

        <button
          type="button"
          className="community-detail-back"
          onClick={onClose}
          disabled={
            deleting || saving
          }
        >
          ←
        </button>

        <span className="community-detail-logo">
          EASYS COMMUNITY
        </span>

        <span className="community-detail-category">
          {category}
        </span>

      </header>


      {/* CONTENT */}

      <section className="community-detail-container">

        <div className="community-detail-top">

          <h1 className="community-detail-title">
            {post.title ||
              "제목 없음"}
          </h1>

          <div className="community-detail-author-area">

            <div className="community-detail-avatar">
              {author.charAt(0)}
            </div>

            <div className="community-detail-author-info">

              <strong className="community-detail-author">
                {author}
              </strong>

              <span className="community-detail-date">
                {formatDateTime(
                  post.createdAt
                )}
              </span>

            </div>

          </div>

        </div>


        <div className="community-detail-divider" />


        {/* 본문 */}

        <article className="community-detail-content">

          <p>
            {post.content ||
              "내용이 없습니다."}
          </p>

          {Array.isArray(
            post.images
          ) &&
            post.images.length > 0 && (
              <div className="community-detail-images">

                {post.images.map(
                  (image, index) => (
                    <img
                      key={`${post.id}-${index}`}
                      src={getImageUrl(
                        image
                      )}
                      alt={`게시글 이미지 ${
                        index + 1
                      }`}
                    />
                  )
                )}

              </div>
            )}

        </article>


        {/* 하단 */}

        <div className="community-detail-bottom">

          <div className="community-detail-stats">

            <button
              type="button"
              className={`community-detail-like-button ${
                isLiked
                  ? "liked"
                  : ""
              }`}
              onClick={handleLike}
              disabled={
                liking ||
                !isLoggedIn
              }
              title={
                isLoggedIn
                  ? "좋아요"
                  : "로그인 후 이용 가능합니다."
              }
            >
              <span className="detail-like-heart">
                {isLiked
                  ? "♥"
                  : "♡"}
              </span>

              <span>
                {likeCount}
              </span>
            </button>


            <span className="community-detail-stat">
              💬{" "}
              {Number(
                post.commentCount || 0
              )}
            </span>


            <span className="community-detail-stat">
              👁{" "}
              {Number(
                post.viewCount || 0
              )}
            </span>

          </div>


          {/* 작성자만 수정/삭제 */}

          {isLoggedIn &&
            isAuthor() &&
            !showEdit && (
              <div className="community-detail-actions">

                <button
                  type="button"
                  className="community-detail-action-button"
                  onClick={() =>
                    setShowEdit(true)
                  }
                >
                  수정
                </button>

                <button
                  type="button"
                  className="community-detail-action-button delete"
                  onClick={
                    handleDelete
                  }
                  disabled={deleting}
                >
                  {deleting
                    ? "삭제 중..."
                    : "삭제"}
                </button>

              </div>
            )}

        </div>


        {/* 수정 */}

        {showEdit && (
          <form
            className="community-detail-edit-form"
            onSubmit={
              handleUpdate
            }
          >

            <h2>
              게시글 수정
            </h2>


            <label htmlFor="community-edit-title">
              제목
            </label>

            <input
              id="community-edit-title"
              type="text"
              value={editTitle}
              onChange={(event) =>
                setEditTitle(
                  event.target.value
                )
              }
              maxLength={200}
              disabled={saving}
            />


            <label htmlFor="community-edit-content">
              내용
            </label>

            <textarea
              id="community-edit-content"
              value={editContent}
              onChange={(event) =>
                setEditContent(
                  event.target.value
                )
              }
              rows={12}
              disabled={saving}
            />


            <div className="community-detail-edit-actions">

              <button
                type="button"
                onClick={() =>
                  setShowEdit(false)
                }
                disabled={saving}
              >
                취소
              </button>

              <button
                type="submit"
                disabled={saving}
              >
                {saving
                  ? "수정 중..."
                  : "수정 완료"}
              </button>

            </div>

          </form>
        )}

      </section>

    </main>
  );
}

export default CommunityDetail;